/* SPDX-License-Identifier: GPL-2.0-or-later */

#pragma once

#define VIAL_KEYBOARD_UID {0x89, 0x99, 0x70, 0xD2, 0x66, 0x8B, 0x6F, 0xEC}

#define RGBLIGHT_ANIMATIONS
#define RGBLIGHT_EFFECT_KNIGHT_LENGTH 2
